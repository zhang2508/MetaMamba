from sklearn.metrics import confusion_matrix
import numpy as np
import torch
from typing import Callable, Tuple, List, Union, Optional
from collections import Counter
from typing import Dict, Any
from torch.utils.data import DataLoader, Dataset
from torch.utils.data.sampler import Sampler
import random
import rasterio
import torch.nn as nn
import os
from datetime import datetime

def compute_metrics(y_true, y_pred):
    cm = confusion_matrix(y_true, y_pred)
    matrix_1 = np.round(cm/np.sum(cm,axis=1)[:, np.newaxis],4)
    per_acc = np.diag(cm)/np.sum(cm,axis=1)
    PA = np.diag(matrix_1) #
    UA = np.diag(np.round(cm / np.sum(cm, axis=0)[:, np.newaxis], 4)) #

    total_correct = np.trace(cm)  #
    total_samples = np.sum(cm)  #
    OA = total_correct / total_samples
    per_class_accuracy = cm.diagonal() / cm.sum(axis=1)  #
    AA = np.nanmean(per_class_accuracy)  #
    pe = np.sum(cm.sum(axis=0) * cm.sum(axis=1)) / (total_samples ** 2)  #
    Kappa = (OA - pe) / (1 - pe) if (1 - pe) != 0 else 0  #

    return OA, AA, Kappa, per_acc, PA, UA, cm, matrix_1

def radiation_noise(data, alpha_range=(0.9, 1.1), beta=1/25):
    alpha = np.float32(np.random.uniform(*alpha_range)) #
    noise = np.random.normal(loc=0., scale=1.0, size=data.shape).astype(np.float32) #
    return alpha * data + beta * noise

def random_mask_batch_image(input_batch, mask_ratio):  #
    batch_size = input_batch.shape[0]
    num_channels = input_batch.shape[1]
    patch_size = input_batch.shape[2]
    random_mask_spatial = torch.rand(batch_size, 1, patch_size, patch_size)
    random_mask_spatial = torch.where(random_mask_spatial > mask_ratio, torch.tensor(1.0), torch.tensor(0.0))
    masked_batch = input_batch * random_mask_spatial
    return masked_batch

# --- 数据增强函数调用主函数 ---
def augment_data_sequentially_by_class(
        batch_data_nhwc: np.ndarray,
        batch_labels_n: np.ndarray,
        augmentations_per_sample: int, #
        augmentation_function: Callable[[np.ndarray], np.ndarray] = lambda s: radiation_noise(s), #
        include_originals: bool = True  #
) -> Tuple[np.ndarray, np.ndarray]: #
    if not isinstance(batch_data_nhwc, np.ndarray) or batch_data_nhwc.ndim != 4:
        raise ValueError("batch_data_nhwc 必须是一个4D NumPy数组 (N, H, W, C)。")
    if not isinstance(batch_labels_n, np.ndarray) or batch_labels_n.ndim != 1:
        raise ValueError("batch_labels_n 必须是一个1D NumPy数组 (N,)。")
    if batch_data_nhwc.shape[0] != batch_labels_n.shape[0]:
        raise ValueError("batch_data_nhwc 和 batch_labels_n 中的样本数量必须匹配。")
    if not isinstance(augmentations_per_sample, int) or augmentations_per_sample < 0:
        raise ValueError("augmentations_per_sample 必须是一个非负整数。")
    if not callable(augmentation_function):
        raise TypeError("augmentation_function 必须是一个可调用的函数。")
    if not isinstance(include_originals, bool):  # 对新参数进行类型检查
        raise TypeError("include_originals 必须是一个布尔值 (True 或 False)。")
    N_in, H, W, C = batch_data_nhwc.shape
    if N_in == 0:
        return np.empty((0, H, W, C), dtype=batch_data_nhwc.dtype), \
               np.empty((0,), dtype=batch_labels_n.dtype)
    versions_per_input_sample = 0
    if include_originals:
        versions_per_input_sample += 1
    versions_per_input_sample += augmentations_per_sample
    if versions_per_input_sample == 0:
        return np.empty((0, H, W, C), dtype=batch_data_nhwc.dtype), \
               np.empty((0,), dtype=batch_labels_n.dtype)

    num_total_output_samples = N_in * versions_per_input_sample
    final_augmented_data = np.empty((num_total_output_samples, H, W, C), dtype=batch_data_nhwc.dtype)
    final_augmented_labels = np.empty((num_total_output_samples,), dtype=batch_labels_n.dtype)
    unique_sorted_labels = np.sort(np.unique(batch_labels_n))
    current_output_idx = 0

    for class_label in unique_sorted_labels:
        class_indices_in_original_batch = np.where(batch_labels_n == class_label)[0]
        for sample_idx_in_original_batch in class_indices_in_original_batch:
            original_sample = batch_data_nhwc[sample_idx_in_original_batch]
            if include_originals:
                if current_output_idx < num_total_output_samples:  #
                    final_augmented_data[current_output_idx] = original_sample
                    final_augmented_labels[current_output_idx] = class_label
                    current_output_idx += 1
                else:  #
                    print("警告: 预分配空间在添加原始样本时已满，提前终止。")
                    return final_augmented_data[:current_output_idx], final_augmented_labels[:current_output_idx]
            if augmentations_per_sample > 0:
                for _ in range(augmentations_per_sample):
                    if current_output_idx >= num_total_output_samples:  #
                        #
                        break  #
                    augmented_sample = augmentation_function(original_sample.copy())
                    final_augmented_data[current_output_idx] = augmented_sample
                    final_augmented_labels[current_output_idx] = class_label  #
                    current_output_idx += 1
            if current_output_idx >= num_total_output_samples:
                break
        if current_output_idx >= num_total_output_samples:
            break  #
    if current_output_idx < num_total_output_samples:
        print(f"警告: 最终填充的样本数 ({current_output_idx}) 少于预分配数量 ({num_total_output_samples}). "
              "将返回实际填充的部分。")
        return final_augmented_data[:current_output_idx], final_augmented_labels[:current_output_idx]

    return final_augmented_data, final_augmented_labels

class Task(object):
    def __init__(self, data, num_classes, shot_num, query_num):
        self.data = data
        self.num_classes = num_classes
        self.support_num = shot_num
        self.query_num = query_num

        class_folders = sorted(list(data))

        class_list = random.sample(class_folders, self.num_classes)

        labels = np.array(range(len(class_list)))

        labels = dict(zip(class_list, labels))

        samples = dict()

        self.support_datas = []
        self.query_datas = []
        self.support_labels = []
        self.query_labels = []
        for c in class_list:
            temp = self.data[c]  # list
            samples[c] = random.sample(temp, len(temp))
            random.shuffle(samples[c])

            self.support_datas += samples[c][:shot_num]
            self.query_datas += samples[c][shot_num:shot_num + query_num]

            self.support_labels += [labels[c] for i in range(shot_num)]
            self.query_labels += [labels[c] for i in range(query_num)]

class FewShotDataset(Dataset):
    def __init__(self, task, split='train'):
        self.task = task
        self.split = split
        self.image_datas = self.task.support_datas if self.split == 'train' else self.task.query_datas
        self.labels = self.task.support_labels if self.split == 'train' else self.task.query_labels

    def __len__(self):
        return len(self.image_datas)

    def __getitem__(self, idx):
        raise NotImplementedError("This is an abstract class. Subclass this class for your particular dataset.")

class HBKC_dataset(FewShotDataset):
    def __init__(self, *args, **kwargs):
        super(HBKC_dataset, self).__init__(*args, **kwargs)

    def __getitem__(self, idx):
        image = self.image_datas[idx]
        label = self.labels[idx]
        return image, label

# Sampler
class ClassBalancedSampler(Sampler):
    ''' Samples 'num_inst' examples each from 'num_cl' pool of examples of size 'num_per_class' '''
    def __init__(self, num_per_class, num_cl, num_inst,shuffle=True):
        self.num_per_class = num_per_class
        self.num_cl = num_cl
        self.num_inst = num_inst
        self.shuffle = shuffle

    def __iter__(self):
        # return a single list of indices, assuming that items will be grouped by class
        if self.shuffle:
            batch = [[i+j*self.num_inst for i in torch.randperm(self.num_inst)[:self.num_per_class]] for j in range(self.num_cl)]
        else:
            batch = [[i+j*self.num_inst for i in range(self.num_inst)[:self.num_per_class]] for j in range(self.num_cl)]
        batch = [item for sublist in batch for item in sublist]

        if self.shuffle:
            random.shuffle(batch)
        return iter(batch)

    def __len__(self):
        return 1

# dataloader
def get_HBKC_data_loader(task, num_per_class=1, split='train',shuffle = False):
    dataset = HBKC_dataset(task,split=split)

    if split == 'train':
        sampler = ClassBalancedSampler(num_per_class, task.num_classes, task.support_num, shuffle=shuffle) #
    else:
        sampler = ClassBalancedSampler(num_per_class, task.num_classes, task.query_num, shuffle=shuffle) #

    loader = DataLoader(dataset, batch_size=num_per_class*task.num_classes, sampler=sampler)

    return loader


def euclidean_metric(a, b):
    n = a.shape[0]
    m = b.shape[0]
    a = a.unsqueeze(1).expand(n, m, -1)
    b = b.unsqueeze(0).expand(n, m, -1)
    logits = -((a - b) ** 2).sum(dim=2)
    return logits
