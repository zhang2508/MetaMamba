import torch
import torch.nn as nn
from torch.autograd import Variable
import numpy as np
import argparse
import h5py
import warnings
from sklearn.neighbors import KNeighborsClassifier
from torch.utils.data import DataLoader, TensorDataset
import math
from utils import utils
from model import mymodels as models
from utils.utils import compute_metrics, euclidean_metric
from utils.utils import augment_data_sequentially_by_class

warnings.filterwarnings("ignore")
np.set_printoptions(linewidth=10000)

def train(data_train, label_train, data_test, label_test, metatrain_data):
    nDataSet = 5
    OA = np.zeros([nDataSet, 1])
    AA = np.zeros([nDataSet, 1])
    k = np.zeros([nDataSet, 1])
    ELEMENT_ACC = np.zeros([nDataSet, CLASS_NUM])
    train_dataset = TensorDataset(torch.Tensor(data_train), torch.LongTensor(label_train))
    test_dataset = TensorDataset(torch.Tensor(data_test), torch.LongTensor(label_test))
    train_loader = DataLoader(train_dataset, batch_size=len(train_dataset), shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=256, shuffle=False)

    for iDataSet in range(nDataSet):
        feature_encoder = models.Network(FEATURE_DIM, TAR_INPUT_DIMENSION, TAR_INPUT_DIMENSION,
                                         N_DIMENSION, CLASS_NUM, PATCH)
        feature_encoder.apply(models.weights_init)
        feature_encoder.cuda()
        feature_encoder.train()

        from calflops import calculate_flops
        input_shape = (1, args.tar_input_dim, args.patch, args.patch)
        flops, macs, params = calculate_flops(model=feature_encoder,
                                              input_shape=input_shape,
                                              output_as_string=True,
                                              output_precision=4,
                                              output_unit="K")
        print("Model:%s   FLOPs:%s   MACs:%s   Params:%s \n" % (args.model_name, flops, macs, params))

        optimizer = torch.optim.Adam(feature_encoder.parameters(), lr=args.learning_rate)
        crossEntropy = nn.CrossEntropyLoss().cuda()

        best_accuracy = 0.0
        best_episdoe = 0
        total_loss_list, train_episode, train_acc_list, test_acc_list, test_episode = [], [], [], [], []

        for episode in range(EPISODE):
            total_hit, total_num = 0.0, 0.0
            task = utils.Task(metatrain_data, CLASS_NUM, SHOT_NUM, QUERY_NUM)
            support_dataloader = utils.get_HBKC_data_loader(task, num_per_class=SHOT_NUM, split="train", shuffle=False)
            query_dataloader = utils.get_HBKC_data_loader(task, num_per_class=QUERY_NUM, split="test", shuffle=True)

            supports, support_labels = next(iter(support_dataloader))
            querys, query_labels = next(iter(query_dataloader))
            support_features, _ = feature_encoder(supports.cuda())
            query_features, _ = feature_encoder(querys.cuda())
            if SHOT_NUM > 1:
                support_proto = support_features.reshape(CLASS_NUM, SHOT_NUM, -1).mean(dim=1)
            else:
                support_proto = support_features
            logits = euclidean_metric(query_features, support_proto)
            loss = crossEntropy(logits, query_labels.cuda().long())

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_hit += torch.sum(torch.argmax(logits, dim=1).cpu() == query_labels).item()
            total_num += querys.shape[0]

            total_loss_list.append(loss.item())
            train_episode.append(episode + 1)

            if (episode + 1) % TEST_EPISODE == 0:
                print(
                    f'train episode {episode + 1:>4d}: loss: {loss.item():.4f}, acc {(total_hit / total_num) * 100:.2f}')
                train_acc_list.append(total_hit / total_num)

            if (episode + 1) % TEST_EPISODE == 0:
                feature_encoder.eval()
                predict = np.array([], dtype=np.int64)
                labels = np.array([], dtype=np.int64)
                all_test_features_list = []
                train_datas, train_labels_knn = next(iter(train_loader))
                with torch.no_grad():
                    train_features, _ = feature_encoder(Variable(train_datas).cuda())

                max_value = train_features.max()
                min_value = train_features.min()
                train_features_norm = (train_features - min_value) * 1.0 / (max_value - min_value)

                KNN_classifier = KNeighborsClassifier(n_neighbors=1)
                KNN_classifier.fit(train_features_norm.cpu().detach().numpy(), train_labels_knn.numpy())

                for test_datas, test_labels_knn in test_loader:
                    with torch.no_grad():
                        test_features, _ = feature_encoder(Variable(test_datas).cuda())
                    all_test_features_list.extend(test_features.detach().cpu().tolist())

                    test_features = (test_features - min_value) * 1.0 / (max_value - min_value)
                    predict_label = KNN_classifier.predict(test_features.cpu().detach().numpy())

                    predict = np.append(predict, predict_label)
                    labels = np.append(labels, test_labels_knn.numpy())

                oa, aa, kappa, per_acc, PA, UA, cm, matrix_1 = compute_metrics(labels, predict)
                print(f"test episode: {episode + 1:>4d} oa: {oa * 100:.2f} aa: {aa * 100:.2f} kappa: {kappa:.4f}")
                test_acc_list.append(oa)
                test_episode.append(episode + 1)
                feature_encoder.train()

                if oa > best_accuracy:
                    torch.save(feature_encoder.state_dict(),f"FSL_feature_encoder_iter{iDataSet}.pkl")
                    best_accuracy = oa
                    best_episdoe = episode
                    OA[iDataSet] = oa
                    AA[iDataSet] = aa
                    k[iDataSet] = kappa
                    ELEMENT_ACC[iDataSet, :] = per_acc

                print(f'best episode: {best_episdoe + 1}, best accuracy={best_accuracy * 100:.2f} \n\n')

def load_and_split_h5_data(h5_path, train_samples_per_class, augment_num=None, include_originals=True):
    with h5py.File(h5_path, 'r') as hf:
        data = hf['data'][:]  #
        label = hf['label'][:]  #

    unique_classes = np.unique(label)
    raw_data_train, raw_label_train = [], []
    raw_data_test, raw_label_test = [], []
    for c in unique_classes:
        idx = np.where(label == c)[0]
        np.random.shuffle(idx)
        train_idx = idx[:train_samples_per_class]
        test_idx = idx[train_samples_per_class:]
        raw_data_train.append(data[train_idx])
        raw_label_train.append(label[train_idx])
        raw_data_test.append(data[test_idx])
        raw_label_test.append(label[test_idx])
    raw_data_train = np.concatenate(raw_data_train, axis=0)
    raw_label_train = np.concatenate(raw_label_train, axis=0)
    data_test = np.concatenate(raw_data_test, axis=0)
    label_test = np.concatenate(raw_label_test, axis=0)
    if augment_num is None:
        augment_num = math.ceil((200 - train_samples_per_class) / train_samples_per_class) + 1

    if augment_num > 0:
        print(f"正在对训练集进行数据增强，每类增强次数: {augment_num}...")
        data_train, label_train = augment_data_sequentially_by_class(
            raw_data_train,
            raw_label_train,
            augmentations_per_sample=augment_num,
            include_originals=include_originals
        )
    else:
        data_train, label_train = raw_data_train, raw_label_train
    data_train = np.transpose(data_train, (0, 3, 1, 2))
    data_test = np.transpose(data_test, (0, 3, 1, 2))
    metatrain_dict = {}
    unique_train_classes = np.unique(label_train)

    for c in unique_train_classes:
        idx = np.where(label_train == c)[0]
        c_train_data = data_train[idx]
        metatrain_dict[int(c)] = list(c_train_data)
    return data_train, label_train, data_test, label_test, metatrain_dict

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Pure Few Shot Visual Recognition")
    parser.add_argument("-f", "--feature_dim", type=int, default=64)
    parser.add_argument("-d", "--tar_input_dim", type=int, default=256)  #
    parser.add_argument("-n", "--n_dim", type=int, default=100) #
    parser.add_argument("-w", "--class_num", type=int, default=6)  #
    parser.add_argument("-st", "--shot_num", type=int, default=1)  #
    parser.add_argument("-bt", "--query_num", type=int, default=19)  #
    parser.add_argument("-e", "--episode", type=int, default=100)
    parser.add_argument("-t", "--test_episode", type=int, default=2)
    parser.add_argument("-l", "--learning_rate", type=float, default=0.001)
    parser.add_argument("-p", "--patch", type=int, default=7)  #
    parser.add_argument("-z", "--train_sample_per_class", type=int, default=5, help='每类抽多少个样本用于训练')
    parser.add_argument("-mn", "--model_name", type=str, default="me")
    args = parser.parse_args()

    FEATURE_DIM = args.feature_dim
    TAR_INPUT_DIMENSION = args.tar_input_dim
    N_DIMENSION = args.n_dim
    CLASS_NUM = args.class_num
    SHOT_NUM = args.shot_num
    QUERY_NUM = args.query_num
    EPISODE = args.episode
    TEST_EPISODE = args.test_episode
    PATCH = args.patch

    h5_dataset_path = "./data/dataset.h5"
    data_train, label_train, data_test, label_test, metatrain_data = load_and_split_h5_data(
        h5_dataset_path,
        train_samples_per_class=args.train_sample_per_class
    )

    print(f"训练集规模: {data_train.shape}")
    print(f"测试集规模: {data_test.shape}")
    print(f"类别数量: {len(metatrain_data.keys())}")
    # =======================================================

    train(data_train, label_train, data_test, label_test, metatrain_data)