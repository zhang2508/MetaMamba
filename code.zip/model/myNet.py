import torch
import torch.nn as nn

try:
    from .mamba import Mamba
except:
    from mamba import Mamba

class SpatialCNNBranch(nn.Module):
    def __init__(self, in_channels, hidden_dim=64):
        super(SpatialCNNBranch, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, hidden_dim, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(hidden_dim)
        self.conv2 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(hidden_dim)
        self.pool2 = nn.AdaptiveMaxPool2d((1, 1))

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.pool2(out)

        return out.view(out.size(0), -1)

class SpectralMambaBranch(nn.Module):
    def __init__(self, in_channels, d_model=64, d_state=16, d_conv=4, expand=2):
        super(SpectralMambaBranch, self).__init__()
        if Mamba is None:
            self.mamba = None
            return

        self.mamba = Mamba(
            d_model=d_model,
            d_state=d_state,
            d_conv=d_conv,
            expand=expand,
        )
        self.norm = nn.LayerNorm(d_model)

    def forward(self, x):
        if self.mamba is None:
            return torch.zeros(x.size(0), x.size(1)).to(x.device)

        B, C, H, W = x.shape
        x_seq = x.view(B, C, -1).transpose(1, 2)
        out = self.mamba(x_seq)
        out = self.norm(out)
        out = out.mean(dim=1)  # (B, D)
        return out

class FeatureExtractor(nn.Module):
    def __init__(self, in_channels, feature_dim=64):
        super(FeatureExtractor, self).__init__()
        self.shallow_conv = nn.Sequential(
            nn.Conv2d(in_channels, feature_dim, kernel_size=1),
            nn.BatchNorm2d(feature_dim),
            nn.ReLU(inplace=True)
        )

        self.spatial_branch = SpatialCNNBranch(in_channels=feature_dim, hidden_dim=feature_dim)
        self.spectral_branch = SpectralMambaBranch(in_channels=feature_dim, d_model=feature_dim)

    def forward(self, x):
        x_shallow = self.shallow_conv(x)
        feat_spatial = self.spatial_branch(x_shallow)
        feat_spectral = self.spectral_branch(x_shallow)

        feat_fused = feat_spatial+feat_spectral
        return feat_fused
